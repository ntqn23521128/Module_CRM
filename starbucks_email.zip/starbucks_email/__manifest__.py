{
    'name': 'Starbucks SendGrid Email',
    'version': '1.0',
    'depends': ['base'],
    'author': 'Sinh Vien',
    'data': [],
    'installable': True,
    'application': True,
}