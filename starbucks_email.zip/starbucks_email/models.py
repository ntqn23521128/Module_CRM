from odoo import models, api, fields
import requests
import json
import datetime

class ResPartner(models.Model):
    _inherit = 'res.partner'

    # Cấu hình SendGrid
    API_KEY = "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" 
    FROM_EMAIL = "nguyenthiquynhnhu26092005@gmail.com"

    # Hàm hỗ trợ gửi API (Dùng chung)
    def _send_sendgrid_api(self, to_email, to_name, subject, html_content):
        url = "https://api.sendgrid.com/v3/mail/send"
        headers = {
            "Authorization": f"Bearer {self.API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "personalizations": [{"to": [{"email": to_email, "name": to_name}], "subject": subject}],
            "from": {"email": self.FROM_EMAIL, "name": "Starbucks Vietnam"},
            "content": [{"type": "text/html", "value": html_content}]
        }
        try:
            return requests.post(url, headers=headers, json=payload)
        except Exception as e:
            return None

    # 1. CRON JOB: Gửi Voucher Đầu Tháng (sinh mã tự động)
    @api.model
    def cron_send_birthday_voucher(self):
        today = datetime.date.today()
        current_month = today.month
        
        # Tên chương trình khuyến mãi đã tạo trong Odoo
        PROGRAM_NAME = "Voucher Sinh Nhật Tự Động" 

        # 1. Tìm chương trình khuyến mãi trong DB
        loyalty_program = self.env['loyalty.program'].search([('name', '=', PROGRAM_NAME)], limit=1)
        
        if not loyalty_program:
            # Ghi log lỗi nếu không tìm thấy chương trình
            self.env['ir.logging'].create({
                'name': 'Cron Birthday',
                'type': 'server',
                'level': 'error',
                'message': f"Lỗi: Không tìm thấy chương trình khuyến mãi tên '{PROGRAM_NAME}'"
            })
            return

        # 2. Tìm khách hàng có sinh nhật trong tháng
        partners = self.search([('birthday', '!=', False), ('email', '!=', False)])
        
        for record in partners:
            if record.birthday.month == current_month:
                
                # 3. Tạo mã coupon độc nhất cho khách hàng
                # Tạo một thẻ coupon mới thuộc chương trình này, gán cho khách hàng này
                coupon = self.env['loyalty.card'].create({
                    'program_id': loyalty_program.id,
                    'partner_id': record.id,
                    'points': 0, # Mặc định
                    'expiration_date': False # Set ngày hết hạn nếu muốn
                })
                
                # Lấy mã code vừa sinh ra
                unique_code = coupon.code

                # 4. Soạn nội dung email với mã ĐỘC NHẤT
                subject = f"🎂 Chào tháng sinh nhật của {record.name}!"
                html_content = f"""
                <div style="font-family: Arial; text-align: center; padding: 20px;">
                    <h2 style="color: #d63384;">HELLO {today.strftime('%B').upper()} BABY!</h2>
                    <p>Tháng này là tháng của bạn. Starbucks gửi tặng bạn món quà nhỏ:</p>
                    <div style="border: 2px dashed #d63384; padding: 15px; display: inline-block; margin: 15px 0; background-color: #fff0f5;">
                        <span style="display:block; font-size:12px; color:#666;">Mã ưu đãi riêng của bạn:</span>
                        <strong style="font-size: 24px; color: #d63384;">{unique_code}</strong>
                    </div>
                    <p>Giảm 50% hoặc Tặng 1 bánh (Chỉ áp dụng cho tài khoản của bạn)</p>
                </div>
                """
                
                # 5. Gửi qua SendGrid
                response = self._send_sendgrid_api(record.email, record.name, subject, html_content)
                
                if response and response.status_code == 202:
                    record.message_post(body=f"🎁 [AUTO] Đã tạo coupon {unique_code} và gửi email sinh nhật.")

    # 2. CRON JOB: Gửi Lời Chúc Đúng Ngày (Chạy hàng ngày)
    @api.model
    def cron_send_birthday_wishes(self):
        today = datetime.date.today()
        current_day = today.day
        current_month = today.month
        
        partners = self.search([('birthday', '!=', False), ('email', '!=', False)])
        
        for record in partners:
            if record.birthday.day == current_day and record.birthday.month == current_month:
                subject = f"🎉 Happy Birthday {record.name}!"
                html_content = f"""
                <div style="font-family: Arial; text-align: center; padding: 20px; background-color: #fff8e1;">
                    <h1 style="color: #ff9800;">CHÚC MỪNG SINH NHẬT!</h1>
                    <p>Hôm nay là một ngày thật đặc biệt.</p>
                    <p>Starbucks chúc <strong>{record.name}</strong> tuổi mới rực rỡ! ☕</p>
                    <p><i>Đừng quên ghé cửa hàng để dùng mã ưu đãi chúng tôi đã gửi đầu tháng nhé!</i></p>
                </div>
                """
                response = self._send_sendgrid_api(record.email, record.name, subject, html_content)
                if response and response.status_code == 202:
                    record.message_post(body="🎂 [AUTO] Đã gửi lời chúc đúng ngày sinh nhật.")