{
    'name': 'Partner Birthday',
    'version': '19.0.1.0.0',
    'summary': 'Thêm ngày sinh vào Contacts',
    'author': 'Bạn',
    'depends': ['base', 'contacts'],
    'data': [
        'views/res_partner_views.xml',
    ],
    'installable': True,
    'application': False,
}